<?php
set_time_limit(0);
include 'classImg.php';
include 'link.php';
//include 'obtener_listado_archivos.php';
$np=0;
//$cn="";

$image_list="import_images_";

global $special_chars,$special_reemplazo;
$special_chars = array('&eacute;','&nbsp;','&frac14;','&deg;','&reg;','&trade;','!','@','$','%','*','"','”','\'','/','.'," ",',',':','.','½','³','¼','¾','(r)','(tm)','&copy;','&frac12;','&frac34;','&#133;','&#145;','&#146;','&#147;','&#148;','&#149;','&#150;','&#151;','&#153;',';','&','#','(',')');
$special_reemplazo = array('e','','1-4','','','','','','','','','-','-','-','-','-',"-",'','','','1-2','3','1-4','3-4','','','','1-2','3-4','','','','','','','','','','','','','-','-');

function imagenes_seleccion($img,$imagenes_folder,$sku,$mf)
{
	global $special_chars,$special_reemplazo;
	
	$carpetas = array();
	//$carpeta_contenedora="D:\dux\Datos\StomaBags Dat\magento\gotcha";
	
	$carpeta_contenedora=$imagenes_folder;
	$carpeta_destino="imagenes_a_subir";
	$n=0;
	$no_encontradas = array();	
	$img_encontrados=array();
	
	if(empty($carpeta_contenedora))
		return $img_encontrados;
	
	//echo print_r($img)." <br > $imagenes_folder <br > $sku <br> $mf";exit;
	
	$ni=0;
	foreach( $img as $image )
	{      
	  if( empty( $image ) )
      {
          continue;
      }
	  $ni++;
      $archivo = trim( $image );
		
		$file_info = pathinfo($archivo);
		
		//temporal
		$archivo=$file_info['basename'];
		
		$nuevo_nombre = $mf.'-'.$sku;
		// $nuevo_nombre = $mf.'-'.$sku;

		$nuevo_nombre=strtolower($nuevo_nombre);
		if($ni>1)
			$nuevo_nombre.='_'.$ni;
		$nuevo_nombre=str_replace($special_chars , $special_reemplazo , $nuevo_nombre).'.'.$file_info['extension'];
		echo("</br>Nuevo Nombre:".$nuevo_nombre);
		
      $encontrada=false;	  
      //foreach( $carpetas as $cr )
      //{
			if( file_exists( $carpeta_contenedora."\\".$archivo ) )
			{
				echo("</br>Image exists");
				$file_info = pathinfo( $archivo );
				//copy( $carpeta_contenedora."\\".$archivo , $carpeta_destino."\\".$nuevo_nombre );
				$image=new thumb();				
				$image->loadImage($carpeta_contenedora."\\".$archivo);								
				//redimensionando si es necesario
				if( $image->width > $image->height )
				{
					if( $image->width > 500 )
					{
						$image->resize(500, 'width');
					}
				}
				elseif( $image->height > 500 )
				{
					$image->resize(500, 'height');
				}
				
				$image->save($carpeta_destino.'\\'.$nuevo_nombre);
				
				$img_encontrados[]=$nuevo_nombre;
				$n++;
				$encontrada = true;
				//break;
			}
      //}      
	}
	return $img_encontrados;
}

function EscapeSQL($val,$convertir=false)
{
    #Propocito:
    #genera un escape para caracteres especiales

    $resultante="";
    //Convirtiendo caracteres especiales a html
    if($convertir)
		$val=htmlentities($val);       
		
    $resultante=AddSlashes($val);
       
	return $resultante;
}
if(isset($_POST['procesar']))
{
	$campos_molde=array("sku"=>"","base_image"=>"","small_image"=>"","thumbnail_image"=>"","additional_images"=>"");
	#echo '<br/>Campos Molde count: '.count($campos_molde);
	
	$np=0;
	$n_parent=$n_child=0;
	//$special_chars = array('!','@','#','$','%','*','(',')','"','”','\'','/','.'," ",',',';','&');
	
	
	$i=0;
	$lista_campos='';
	foreach($campos_molde as $campo_nombre=> $val_campo)
	{
		if($i>0)
			$lista_campos .=",";
					
		$lista_campos .="`$campo_nombre`";
		$i++;
	}	
	//cambiar consulta 
	/******************************para script php simples images*******************************************************************/
	$consulta="
SELECT sku,	image AS img , manufacturer  FROM `imagenes`;

	";
	
	$rs = mysqli_query($cn, $consulta ) or die ( mysqli_error($cn) . " #001" );

		while( $row = mysqli_fetch_array($rs) )
		{
			
			$manufacturer = trim($row['manufacturer']); //'KCI Colombia';			//cambiar
			$sku = trim($row['sku']);						//cambiar
			
			$image='';
			$image=$row['img'];						
			//$image=$row['image'];															//cambiar
			
			//$imagenes_folder="";															//cambiar
			$imagenes_folder="images";
			//$imagenes_folder="D:\STOMABAGS\A3B Scientific\imagenes\\".$sku_mf;			//cambiar
			//$imagearray=listFiles("D:\STOMABAGS\A3B Scientific\imagenes\\".$sku_mf);
			
			
			$imagearray=explode(',',$image);
			$imagenes=array();
			if(is_array($imagearray))
			{
				foreach($imagearray as $im)
				{
					$basename=basename($im);
					if(empty($basename))
						continue;
					
					$imagenes[]=$basename;
				}
			}
			
			$campos=array( 0 => $campos_molde );	
			
			$special_htmlchars = array('”','™','•','®','‘','©','½','³','¼','¾',"(r)","(tm)",'&reg;');
			$special_htmlreemplazo = array('"','','-','','-','','&frac12;','&sup3;','&frac14;','&frac34;','','','');
			
			$campos[0]['sku']=EscapeSQL( $sku);
			
			
			if( count( $imagenes ) > 0 )
			{
				//$carpeta_1=substr($row['product_full_image'],
				$imagenes2=imagenes_seleccion($imagenes,$imagenes_folder,$sku,$manufacturer);
				if( count( $imagenes2 ) > 0 )
				{
					$campos[0]['base_image']=$imagenes2[0];
					$campos[0]['small_image']=$imagenes2[0];
					$campos[0]['thumbnail_image']=$imagenes2[0];
					$campos[0]['additional_images']=implode( ',' , $imagenes2 );
				}
			}
			
			foreach($campos as $fila=>$c )
			{		
				$query ="INSERT INTO ".$image_list." ( $lista_campos )values(";
				$i=0;
				foreach($c as $valor)
				{
					if($i>0)
						$query .=",";
					$query .='\''.$valor.'\'';
					$i++;
				}
				$query .= ")";
				mysqli_query($cn, $query)or die(mysqli_error($cn)." #006 <br /> ".$query);
				$np++;
			}

			
		}
	
}

if($np >0 )
{
 echo "Numero de filas: $np <br />";
}
?>
<html>
<head><title>Crear listado para importar productos</title></head>
<body>
<form method="post" >
<input type="hidden" name="procesar" value="1"/>
<input type="submit" value="Crear listado para importar productos" />
</form>
</body>
</html>