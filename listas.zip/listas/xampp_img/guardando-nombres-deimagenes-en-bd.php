<?php
set_time_limit(0);
include 'link.php';
$dir="Images";
$directorio=opendir($dir); 
echo "<b>Directorio actual:</b><br>$dir<br>"; 
$n=0;
while( $archivo = readdir($directorio))
{
	$archivo=basename($archivo);
	echo $archivo.'<br>';
	mysqli_query($cn,"INSERT INTO `images` (`nombre`) VALUES ('$archivo') LIMIT 0,5000") or die (mysqli_error($cn) . " #err mysql");
	$n++;
}
closedir($directorio); 
echo "Total:$n ";
?> 


