<?php
//$conn_db="berg";
$conn_db="imagenes";
$cn=mysqli_connect ("localhost", "root", "", $conn_db )or die('I cannot connect to the database because: ');

$db = new PDO('mysql:host=localhost;port=3306;dbname='.$conn_db.';charset=utf8', 'root', '');

$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

mysqli_select_db ($cn, $conn_db);

?>