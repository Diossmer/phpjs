<?php

function showFiles($path){
    $dir = opendir($path);
    $files = array();
    while ($current = readdir($dir)){
        if( $current != "." && $current != "..") {
            if(is_dir($path.$current)) {
                showFiles($path.$current.'/');
            }
            else {
                $files[] = $current;
            }
        }
    }
    //echo '<h2>'.$path.'</h2>';
    //echo '<ul>';
    for($i=0; $i<count( $files ); $i++){
        echo '<li>'.$path.$files[$i]."</li>";
    }
    //echo '</ul>';
}

showFiles($_SERVER['DOCUMENT_ROOT'].'/marcia_htdocs/Listas/Chile/Fabricantes Varios Img/xampp/images/');
?>