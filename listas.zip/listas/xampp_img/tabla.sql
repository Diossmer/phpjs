/*Table structure for table `images` */

DROP TABLE IF EXISTS `images_base_aidsmedicalwaste`;

CREATE TABLE `mg_images_base_frontier` (
  `nombre` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



SELECT * FROM `ds_images_base_cutisoft` a
INNER JOIN `todos_los_productos_stomabags_completo_sbmedical_chilem2` b
ON REPLACE(REPLACE(REPLACE(REPLACE(a.nombre,'.jpg',''),'Halyard Health - ',''),'Halyard-Health-',''),'.jpef','')= b.sku_mf
WHERE b.manufacturer LIKE '%Halyard Health%'
AND country_origin LIKE '%CHILE%'
GROUP BY sku