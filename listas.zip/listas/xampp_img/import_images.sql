CREATE TABLE `import_images_` (
  `sku` VARCHAR(255) DEFAULT NULL,
  `base_image` TEXT,
  `small_image` TEXT,
  `thumbnail_image` TEXT,
  `additional_images` TEXT
) ENGINE=MyISAM DEFAULT CHARSET=utf8

----query

CREATE TABLE `ds_images_cutisoft` SELECT sku, GROUP_CONCAT(nombre) AS img FROM `ds_images_base_dimeda` a
INNER JOIN `todos_los_productos_stomabags_completo_sbmedical_colombiam2` b
ON REPLACE(REPLACE(a.nombre,'.jpg',''),'.png','')= b.sku_mf
WHERE b.manufacturer LIKE '%Dimeda%'
GROUP BY sku
LIMIT 2000

CREATE TABLE `import_images_fabricvarios` (
  `sku` varchar(255) DEFAULT NULL,
  `base_image` text,
  `small_image` text,
  `thumbnail_image` text,
  `additional_images` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8