<?php

	/*imports list*/
$database='ListaTrabajo';
$password='diossmer';
$simples_list='import_list_';
$grouped_list='import_list_group_';
$preliminar_list='import_list_grouped_';
$association = 'association_test_';
$simples_list.=$database;
$grouped_list.=$database;
$preliminar_list.=$database;
$association.=$database;
?>
