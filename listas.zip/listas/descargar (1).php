<?php
	$user="root";
	$pass="";
	$host="localhost";
	$db_name="fabrication";
	$cn=mysqli_connect ($host,$user,$pass,$db_name) or die('I cannot connect to the database: ');
	$man_ori="lista";
	$man=strtolower(str_replace(' ', '_', $man_ori)) ;
	$consulta="SELECT sku_mf AS sku,imagen FROM `".$man."` WHERE imagen!='0' LIMIT 99999;";
	$rs = mysqli_query($cn, $consulta ) or die ( mysqli_error($cn) . " #001" );
	$a=0;
	mysqli_query($cn,"CREATE TABLE IF NOT EXISTS am_".$man."_img_2 (sku_mf VARCHAR(50) NOT NULL,img VARCHAR(100) NOT NULL)")or die(mysql_error() . " #err mysql");
	$carpeta_destino="".$man_ori."";
	if (!file_exists($carpeta_destino)) {
		mkdir($carpeta_destino, 0777, true);
		echo "Carpeta Creada: ".$carpeta_destino."<br>";
	}
	while( $row = mysqli_fetch_array($rs) ){
		if (strpos($row['imagen'], ',')) {
			$array=explode(',', $row['imagen']);
			for ($i=0; $i < count($array); $i++) { 
				$url = $array[$i];
				$name = $row['sku']."--".($i+1).'.jpg';
				$sku=$row['sku'];
				//echo $name." <===> ".$url."<br>";
				if(!is_file($carpeta_destino.'/'.$name)){
					$source = file_get_contents($url);
					file_put_contents($carpeta_destino.'/'.$name, $source);
					echo 'Se ha descargado la imagen: '.$name."<br>";
					$a++;
				}else{
					$source = file_get_contents($url);
					$name_aux = explode(".", $name);
					$name = $name_aux[0]."(1).jpg";
					file_put_contents($carpeta_destino.'/'.$name, $source);
					echo 'Se ha descargado la imagen: '.$name."<br>";
					$a++;
				}
				mysqli_query($cn,"INSERT INTO am_".$man."_img_2(`sku_mf`,`img`)VALUES('$sku','$name')")or die(mysqli_error($cn) . " #err mysql");
			}
		}else{
			$url = $row['imagen'];
			$name = $row['sku'].'.jpg';
			$sku=$row['sku'];
			//echo $name." <===> ".$url."<br>";
			if(!is_file($carpeta_destino.'/'.$name)){
				$source = file_get_contents($url);
				file_put_contents($carpeta_destino.'/'.$name, $source);
				echo 'Se ha descargado la imagen: '.$name."<br>";
				$a++;
			}else{
				$source = file_get_contents($url);
				$name_aux = explode(".", $name);
				$name = $name_aux[0]."(1).jpg";
				file_put_contents($carpeta_destino.'/'.$name, $source);
				echo 'Se ha descargado la imagen: '.$name."<br>";
				$a++;
			}
			mysqli_query($cn,"INSERT INTO am_".$man."_img_2(`sku_mf`,`img`)VALUES('$sku','$name')")or die(mysqli_error($cn) . " #err mysql");
		}
		/*
		echo $row['img']."<br>";		*/
	}
	echo 'Se ha descargado un total de '.$a." imagenes.<br>";
?>