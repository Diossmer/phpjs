<?php
//$conn_db="therapro";
require 'vars.php';
require 'querys.php';

$cn=mysqli_connect ("localhost", "root", "$password" )or die('I cannot connect to the database because: ');
	session_start();
if (isset($_POST['db'])) {
	$_SESSION['ok']=false;
	mysqli_query($cn,"create database ".$database);
	$cn=mysqli_connect ("localhost", "root", "$password",$database )or die('I cannot connect to the database because:');
	require_once 'querys.php';
	mysqli_query($cn,$imports_group);
	echo '<br>imports_group'.mysqli_error($cn);
	mysqli_query($cn,$imports);
	echo '<br>imports'.mysqli_error($cn);
	mysqli_query($cn,$imports_images);
	echo '<br>imports_images'.mysqli_error($cn);
	mysqli_query($cn,$imports_association);
	echo '<br>imports_association'.mysqli_error($cn);
	$_SESSION['ok']= true;
}

if (isset($_POST['lt'])) {
	$_SESSION['ok']=false;
	mysqli_query($cn,"create database ".$database);
	$cn=mysqli_connect ("localhost", "root", "$password",$database )or die('I cannot connect to the database because:');
	require_once 'querys.php';
	mysqli_query($cn,$limpiar_tablas1);
	echo '<br>limpiar_tablas1'.mysqli_error($cn);
	mysqli_query($cn,$limpiar_tablas2);
	echo '<br>limpiar_tablas2'.mysqli_error($cn);
	mysqli_query($cn,$limpiar_tablas3);
	echo '<br>limpiar_tablas3'.mysqli_error($cn);
	mysqli_query($cn,$limpiar_tablas4);
	echo '<br>limpiar_tablas4'.mysqli_error($cn);
	$_SESSION['ok']= true;
}


if (isset($_POST['reset'])) {

	unset($_SESSION);
	session_start();
	session_destroy();
	session_start();
	$_SESSION['ok']= true;
	header('Location: Import_simples.php');
}

if (isset($_SESSION['ok'])) {

	$conect=mysqli_connect ("localhost", "root", "$password",$database )or die('I cannot connect to the database because: ');
}else{echo "naranjas conect <br>";}
?>
 
<span><br> 
<?php
echo "BD:                             "."<br>";
echo $database;
?>
</span>
<br><br><br>
<form method="post" >
<input type="hidden" name="db" value="1"/>
<input type="submit" value="Crear base de datos" />
</form>

<form method="post" >
<input type="hidden" name="lt" value="1"/>
<input type="submit" value="Limpiar Tablas" />
</form>

<form method="post" >
<input type="hidden" name="reset" value="1"/>
<input type="submit" value="Restaurar sesion" />
</form>
<?php

if (isset($_SESSION['ok'])) {
	echo "base de datos creada con exito!! <br>";
	$db = new PDO('mysql:host=localhost;port=3306;dbname='.$database.';charset=utf8', 'root', "$password");
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
}else{echo "naranjas pdo <br>";}

if (isset($_POST['imagenes'])) {

	header('Location: guardando-nombres-deimagenes-en-bd.php');
}
?>

<form method="post" >
<input type="hidden" name="imagenes" value="1"/>
<input type="submit" value="Insertar imagenes a la base de datos" />
</form>
