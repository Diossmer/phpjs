<?php
$username = "root";
$password = "";
$hostname = "localhost"; 
$database = "stomabags2";

//connection to the database
$cn = mysqli_connect($hostname, $username, $password)
  or die("I cannot connect to the database because: ".mysqli_error($cn).'#003');
echo "Connected to MySQL<br>";
mysqli_select_db ($cn, $database);	
?>