<?php
set_time_limit(0);
#include 'classImg.php';


$np=0;
global $special_chars,$special_reemplazo;
$special_chars = array('&nbsp;','&frac14;','&deg;','&reg;','&trade;','!','@','$','%','*','"','”','\'','/','.'," ",',',':','.','½','³','¼','¾','(r)','(tm)','&copy;','&frac12;','&frac34;','&#133;','&#145;','&#146;','&#147;','&#148;','&#149;','&#150;','&#151;','&#153;',';','&','#','(',')');
$special_reemplazo = array('','1-4','','','','','','','','','-','-','-','-','-',"-",'','','','1-2','3','1-4','3-4','','','','1-2','3-4','','','','','','','','','','','','','-','-');

function parent_category($parent_id,$cn)
{
	
    #Proposito:devolver nombre, status y id del parent
		$rs_hijos=mysqli_query($cn,"SELECT p.entity_id,p.parent_id,p.path,p.level,p.children_count,s.value AS `name`,t.value AS is_active
FROM `usa_catalog_category_entity` AS p
INNER JOIN `usa_catalog_category_entity_varchar` AS s ON p.entity_id=s.entity_id
left JOIN `usa_catalog_category_entity_int` AS t ON p.entity_id=t.entity_id
		WHERE p.entity_id=('".$parent_id."') ;")or die(mysqli_error($cn).'#001');	
 
		$resultante = mysqli_fetch_array($rs_hijos);
	return $resultante;
}

if(isset($_POST['procesar']))
{	
	include 'link.php';
	echo "Inicio ". date('Y-m-d g:i:a') ."<br />";


	$np=0;

	$consulta="
SELECT p.entity_id,p.parent_id,p.path,p.level,p.children_count,s.value AS `name`,t.value AS is_active,s.store_id,s.attribute_id,t.store_id,t.attribute_id
FROM `usa_catalog_category_entity` AS p
INNER JOIN `usa_catalog_category_entity_varchar` AS s ON p.entity_id=s.entity_id
LEFT JOIN `usa_catalog_category_entity_int` AS t ON p.entity_id=t.entity_id
WHERE s.store_id=0 AND s.attribute_id=41 AND t.store_id=0 AND t.attribute_id=42;
";
	
	$rs = mysqli_query($cn, $consulta ) or die ( mysqli_error($cn) . " #002" );

		while( $row = mysqli_fetch_array($rs) )
		{
			$path='';
			$is_active='';
			
			$parent_id=$row['parent_id'];
			$path=$row['name'];
			$is_active=$row['is_active'];
			
			$parent=parent_category($row['parent_id'],$cn);
			$path=$parent['name'].'/'.$path;
			$is_active=$parent['is_active'].'/'.$is_active;
			
			while($parent['parent_id']>0)
			{
				$parent=parent_category($parent['parent_id'],$cn);
				$path=$parent['name'].'/'.$path;
				$is_active=$parent['is_active'].'/'.$is_active;
			}
			
			echo 'PATH: '.$path.'<br>';
				$query ="INSERT INTO categories_path_name ( entity_id,path_name,is_active )
				values(".
				$row['entity_id'].", '".
				addslashes ($path)."', '".addslashes ($is_active)."');";
				
				echo 'query: '.$query.'<br>';

				mysqli_query($cn, $query)or die(mysqli_error($cn)." #003 <br /> ".$query);
				echo '<br>'.$np. ' - inserted<br>';

			$np++;
			
		}

/* cerrar la conexión */
mysqli_close($cn);
}

if($np >0 )
{
 echo "Numero de filas: $np <br />";

echo "Final ". date('Y-m-d g:i:a') ."<br />";

}
?>
<html>
<head><title>categories path name</title></head>
<body>
<form method="post" >
<input type="hidden" name="procesar" value="1"/>
<input type="submit" value="comenzar" />
</form>
</body>
</html>