/*para actualizar tablas en SSH*87
/*
mysqldump --skip-add-locks --skip-triggers -u usa92733 --password='En^kxrbi7D8b8pVt' sbmedical_usa \
usa_catalog_category_entity_varchar usa_catalog_category_entity_int usa_catalog_category_entity \
 > tablas_procesos2.sql
 
 
mysql --port=3310 -h 66.45.250.202 -u lst8273 --password='0zJPq3y8~hncNnog' sblistas_procesos < tablas_procesos2.sql
*/


/*pasar bases a localhost: usa_catalog_category_entity y usa_catalog_category_entity_varchar*/
SELECT COUNT(*) FROM `usa_catalog_category_entity`;#19443
SELECT COUNT(*) FROM  usa_catalog_category_entity_int;#95388
SELECT COUNT(*) FROM `usa_catalog_category_entity_varchar`;#122307



/*revisar categorias huerfanas*/
SELECT * FROM `usa_catalog_category_entity` WHERE parent_id NOT IN (SELECT entity_id FROM `usa_catalog_category_entity`);


TRUNCATE `categories_path_name`;


#correr  php: 
http://localhost/categories_path_name_2.php

/*para quitar root catalog*/
UPDATE `categories_path_name` SET `path_name`=REPLACE(path_name,'Root Catalog/',''),is_active=SUBSTRING(is_active,3,LENGTH(is_active)-2);

SELECT * FROM categories_path_name ORDER BY path_name
;

 #revision si hay HUERFANOS
 SELECT * FROM categories_path_name WHERE path_name LIKE '/%' ORDER BY path_name
 ;
 
 /*esoto solo si hay q borrar huerfanos*/
 /*pma*/
 SELECT * FROM sbmedical_usa.usa_catalog_category_entity WHERE entity_id IN (
#  SELECT entity_id FROM categories_path_name WHERE path_name LIKE '/%';
''
 );
 
 DELETE FROM sbmedical_usa.usa_catalog_category_entity WHERE entity_id IN (
#  SELECT entity_id FROM categories_path_name WHERE path_name LIKE '/%';
''
 );