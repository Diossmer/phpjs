<?php
global $special_chars,$special_reemplazo;

$special_chars = array('+','&nbsp;','&frac14;','&deg;','&reg;','&trade;','!','@','$','%','*','"','”','\'','/','.'," ",',',':','.','½','³','¼','¾','(r)','(tm)','&copy;','&frac12;','&frac34;','&#133;','&#145;','&#146;','&#147;','&#148;','&#149;','&#150;','&#151;','&#153;',';','&','#','(',')');
$special_reemplazo = array('plus','','1-4','','','','','','','','','-','-','-','-','-',"-",'-','','','1-2','3','1-4','3-4','','','','1-2','3-4','','','','','','','','','','','','','-','-');

if(isset($_POST['procesar_family'])){
	echo "Inicio ". date('Y-m-d g:i:a') ."<br />";

	$campos_molde=array("sku"=>"","sku_supplier"=>"","sku_mf"=>"","sku_mfs_list"=>"","store_view_code"=>"","attribute_set_code"=>"","product_type"=>"","category_ids"=>"","product_websites"=>"","name"=>"","description"=>"",
	"short_description"=>"","price"=>"","weight"=>"","manufacturer"=>"","manufacturer_original"=>"","supplier"=>"","base_image"=>"","small_image"=>"","thumbnail"=>"","additional_images"=>"","status"=>"","visibility"=>"","page_layout"=>"",
	"options_container"=>"","tax_class_name"=>"","type_pouch"=>"","color_pouch"=>"","cost"=>"","sold_by"=>"","hcpcs"=>"","qty"=>"","use_config_min_qty"=>"","is_qty_decimal"=>"","use_config_backorders"=>"","product_online"=>"",
	"use_config_min_sale_qty"=>"","use_config_max_sale_qty"=>"","is_in_stock"=>"","use_config_notify_stock_qty"=>"",
	"manage_stock"=>"","use_config_manage_stock"=>"","use_config_qty_increments"=>"","qty_increments"=>"","use_config_enable_qty_inc"=>"","enable_qty_increments"=>"",
	"is_decimal_divided"=>"","sku_simple_children"=>"","associated_skus"=>"","url_key"=>"","meta_title"=>"","meta_description"=>"","product_name_in_group"=>"",
	"shipping_per_product"=>"","product_color"=>"","product_video_embed"=>"","product_size"=>"","free_shipping"=>"","free_shipping_w_tax"=>"",
	"product_options_custom"=>"","supplier_abr"=>"",'supplier_original'=>'',"sold_by_qty"=>"","sold_by_uom"=>"","youtube_video"=>""
	,"comments"=>"","map_value"=>"","msrp_enabled"=>"","sb_group_additional_cols"=>"","sb_group_style"=>"");
	
	$np=0;
	$n_parent=$n_child=0;
	$i=0;
	$lista_campos='';
	foreach($campos_molde as $campo_nombre=> $val_campo)
	{
		if($i>0)
			$lista_campos .=",";	
			$lista_campos .="`$campo_nombre`";
			$i++;
	}	
	//cambiar consulta 
	$consulta="
	/*para script*/
	SELECT * FROM ".$preliminar_list."; ";
	$array_sku_order=array('sku'=>'sku_mf');
	
foreach($db->query($consulta) as $row)
{

	$sku_list=explode('|',$row['sku2']);
		$sku_child=$row['sku1'];			
		$sku_order=explode('|',$row['sku_ord']);			
		unset($array_sku_order);
		
		foreach($sku_order as $c => $v)
		{
			$clave='';
			$valor='';
			$pos = strrpos($v, "::");
			$clave=substr($v,0,$pos).'temp';
			$valor=substr($v,$pos+2,strlen($v)-1);
			if (empty($array_sku_order))
				$array_sku_order=array(	$clave => $valor );
			else
				$array_sku_order[$clave]=$valor;	
		}
			
		$sku_order2=explode('|',$row['sku_ord2']);				
		unset($array_sku_order2);
		
		foreach($sku_order2 as $c => $v)
		{
			$clave='';
			$valor='';
			$pos = strrpos($v, "::");
			$clave=substr($v,0,$pos).'temp'; // el temp del final sirve para q la funcion array_multisort no cambie las claves del array que no son texto
			$valor=substr($v,$pos+2,strlen($v)-1);
				
			if (empty($array_sku_order2))
				$array_sku_order2=array(	$clave => $valor );
			else
				$array_sku_order2[$clave]=$valor;	
		}
		array_multisort($array_sku_order,  SORT_NATURAL | SORT_FLAG_CASE, $array_sku_order2, SORT_NATURAL | SORT_FLAG_CASE );
	
		foreach($array_sku_order as $c => $v) //quitar el temp del final de las claves del array
		{	
			$oldkey=$c;
			$newkey=substr($oldkey,0,strlen($oldkey)-4);
			$array_sku_order[$newkey] = $array_sku_order[$oldkey];
			unset($array_sku_order[$oldkey]);
		}

		echo '<br>';
		echo 'array_sku_order: ';
		print "<pre>";
		print_r($array_sku_order);
		print "</pre>";
		echo '<br>';
		echo 'array_sku_order2: ';
		print "<pre>";
		print_r($array_sku_order2);
		print "</pre>";		
			/******************************************************************************/
		echo "--->".$sku = $sku_list[0].' - '.$sku_list[count($sku_list)-1];
		echo "--->>".$sku= substr($sku,0,60);
		$skumf_list=explode('|',$row['sku_mf']);
			
		if (strcasecmp (reset($array_sku_order),end( $array_sku_order ))==0)
			$sku_mf = reset($array_sku_order);
		else
			$sku_mf =reset($array_sku_order).' To: '.end( $array_sku_order );
			
		echo '<br>SKUMF: '.$sku_mf,'<br>';
		$cn=mysqli_connect ("localhost", "root", "$password",$database )or die('I cannot connect to the database because:');
		$rs_hijos= mysqli_query($cn,"SELECT description,manufacturer_original
		FROM ".$simples_list."
		WHERE sku IN ('".implode("','",$sku_list)."') 
		ORDER BY sku_mf");
				
		$description='';
		$manufacturer_original='';
		while( $row_hijos = mysqli_fetch_array($rs_hijos) )
		{	

			if( empty($manufacturer_original) )
			$manufacturer_original=$row_hijos['manufacturer_original'];
			
			if( strlen($row_hijos['description']) > strlen($description) )
			{
				$short_description=$row_hijos['description'];
			}		
		}			
			
		$name=$row['new_name'];			
		if( empty( $name ) )
		$name=trim( $product_name_in_group );	
		$manufacturer= $row['manufacturer2'];
		$manufacturer_name=$manufacturer;
		$short_description=trim( $short_description );
		$short_description=str_replace("\n", "<br />", $short_description);
		if(empty($short_description))
			{
				$short_description=$name;
			}
		$description=$short_description;
		$hcpcs='';
		$costo = 0;
		$precio = 0;
		$free_shipping_w_tax="No";
		$free_shipping="No";
		$price_shipping='';	
		$imagenes=array();		
		$weight ='';	
		$name_original=$name;
		$campos=array( 0 => $campos_molde );	
		$sb_group_additional_cols=$row['sb_group_additional_cols'];
		$map_value=0;
		$msrp_enabled=0;						//1=Yes, 0=No
		$price_shipping=0;								//cambiar				
		$free_shipping_w_tax="No";
		$free_shipping="No";							//cambiar
		$comments='';								//cambiar	
		$sold_by = '';			//cambiar
		$sold_by_qty=''; 						//cambiar
		$sold_by_uom=$sold_by; 		//cambiar
		$name_original=$name;
		$campos=array( 0 => $campos_molde );	
		$special_htmlchars = array('”','™','•','®','‘','©','½','³','¼','¾',"(r)","(tm)",'&reg;');
		$special_htmlreemplazo = array('"','','-','','-','','&frac12;','&sup3;','&frac14;','&frac34;','','','');
		$name =  str_replace( $special_htmlchars , $special_htmlreemplazo , $name );
		$name2=$name;
		$name=$manufacturer_name;			
		$name .= " - From: ".$sku_mf. " - ".$name2;//CAMBIAR
		echo "prueba nombre familia: ".$name;
		$description = str_replace( $special_htmlchars , $special_htmlreemplazo , $description );
		$short_description = str_replace( $special_htmlchars , $special_htmlreemplazo , $short_description );
			/*******GRUPACION EXTRA************/
		if(empty($row['agrupacion']));
		else;	
		$campos[0]['sku']=EscapeSQL( $sku);
		$sku_mfs_list=$row['sku_mfs_list'];
		if(strlen ( $sku_mfs_list )>255){
			$sku_mfs_list = EscapeSQL(utf8_encode(substr($sku_mfs_list,0,254)));
		    		$sku_mfs_list=substr($sku_mfs_list,0,strrpos($sku_mfs_list, ","));
    		$campos[0]['sku_mfs_list']=EscapeSQL($sku_mfs_list);
		}else{
			$campos[0]['sku_mfs_list']=EscapeSQL($sku_mfs_list);
		}
		$campos[0]['sku_mf']=EscapeSQL($sku_mf);	
		if(empty($campos[0]['sku_mf']))
		$campos[0]['sku_mf']=$campos[0]['sku'];	
		$campos[0]['attribute_set_code']='Migration_Default';
		$campos[0]['product_websites']='base';
		$campos[0]['weight']=$weight;
		$campos[0]['product_online']='1';
		$campos[0]['name']=EscapeSQL($name);
		$campos[0]['product_name_in_group']=EscapeSQL($name2);
		$campos[0]['description']= $description;
		$campos[0]['short_description']= $short_description;
		$campos[0]['manufacturer']=EscapeSQL($manufacturer_name);
		$campos[0]['manufacturer_original']=EscapeSQL($manufacturer_original);
		$campos[0]['product_type']='grouped';									
		$campos[0]['status']=1;
		$campos[0]['visibility']='Catalog, Search';
		$campos[0]['page_layout']='1 column';
		$campos[0]['options_container']='Product Info Column';
		$campos[0]['tax_class_name']='none';
		$campos[0]['cost']=$costo;
		$campos[0]['sold_by']='';  /*dejar en blanco, por requerimiento de sergio b*/
		$campos[0]['sold_by_qty']='';
		$campos[0]['sold_by_uom']='';
		$campos[0]['hcpcs']=$hcpcs;
		$campos[0]['qty']=100;
		$campos[0]['use_config_min_qty']=1;
		$campos[0]['is_qty_decimal']=0;
		$campos[0]['use_config_backorders']=1;
		$campos[0]['use_config_min_sale_qty']=1;//cantidades minimas en el carrito
		$campos[0]['use_config_max_sale_qty']=1;
		$campos[0]['is_in_stock']=1;
		$campos[0]['use_config_notify_stock_qty']=1;
		$campos[0]['manage_stock']=0;
		$campos[0]['use_config_manage_stock']=1;
		$campos[0]['use_config_qty_increments']=1;
		$campos[0]['qty_increments']=0;
		$campos[0]['use_config_enable_qty_inc']=1;
		$campos[0]['enable_qty_increments']=0;
		$campos[0]['is_decimal_divided']=0;		
		$campos[0]['shipping_per_product']=$price_shipping;	
		$campos[0]['sb_group_additional_cols']=$sb_group_additional_cols;
		$campos[0]['sb_group_style']='Custom Columns';
		$campos[0]['store_view_code']='';
			/**PARA ORDENACION**/
		$campos[0]['associated_skus']=$sku_child;
		if(strlen ( $sku_child )>255){ // sku simple children es un campo de referencia en magento, es de 255 caracteres
			$meta_description = substr($sku_child,0,254);
    		$meta_description=substr($sku_child,0,strrpos($sku_child, ","));
    		$campos[0]['sku_simple_children']=$sku_child;
		}else{
			$campos[0]['sku_simple_children']=$sku_child;
		}
		$sku_child='';
		$numItems = count($array_sku_order);
		$i = 0;
		foreach ($array_sku_order as $clave => $valor) {
			
			echo "item: $clave - SKU_MF: $valor<br />";
			//$sku_child.=$valor.'::'.$clave;
			
			$i++;
			if ($i <= $numItems-1) {
				$sku_child.=$clave;
			}
			if($i <= $numItems-1) 
				$sku_child.=',';
		}
		echo $sku_child.'<br />';
		$campos[0]['comments']=$comments;	
		$campos[0]['map_value']=$map_value;
		$campos[0]['msrp_enabled']=$msrp_enabled;
		$campos[0]['free_shipping']=$free_shipping;									///cambiar
		$campos[0]['base_image']=$row['image'];
		$campos[0]['small_image']=$row['image'];
		$campos[0]['thumbnail']=$row['image'];
		$campos[0]['additional_images']=$row['gallery'];
		$campos[0]['price']=$precio;
		
		$url_key = trim($manufacturer_name) . "-" . trim($sku_mf) . "-" . trim($name2)."-".$sold_by."-grp";
		$url_key=$url_key =str_replace($special_chars , $special_reemplazo , $url_key);		
		$url_key=strtolower(trim($url_key,'-'));
		
		while(strpos($url_key,'--')){

			$url_key=str_replace('--' , '-' , $url_key);
			$url_key=str_replace('+' , 'plus' , $url_key);
			if (strlen($url_key)>250)
			$url_key=substr($url_key,0,249);
			$url_path=$url_key;	
			$campos[0]['url_key']=$url_key;
			$campos[0]['meta_title']=EscapeSQL(utf8_encode($name));	
			$meta_description =EscapeSQL(utf8_encode($name ." " . EscapeSQL($sku_mfs_list)));
			if(strlen ( $meta_description )>255){
				$meta_description = EscapeSQL(utf8_encode(substr($meta_description,0,220)));
	    		$meta_description=substr($meta_description,0,strrpos($meta_description, " "));
	    		$campos[0]['meta_description']=EscapeSQL($meta_description);
			}else{
				$campos[0]['meta_description']=EscapeSQL($meta_description);
			}
			$category_ids='';
			$array_category_ids_sb=explode(',',$category_ids);
			sort($array_category_ids_sb);
			$array_category_ids_sb=array_unique($array_category_ids_sb);
			$category_ids=implode(',',$array_category_ids_sb);	
			$campos[0]['category_ids']=$category_ids;
		}	
		foreach($campos as $fila=>$c)
			{		
				$query ="INSERT INTO ".$grouped_list." ( $lista_campos )values(";
					$i=0;
				foreach($c as $valor)
				{
					if($i>0)
						$query .=",";
						$query .='\''.$valor.'\'';
						$i++;
				}
				$query .= ")";
				$affected_rows = $db->exec($query);
				echo $numItems.' Items <br />';
				echo $affected_rows.' Row affected <br>';
				$np++;
		}  //fin del while		
}

		
if($np >0 )
{
	echo "<br>Numero de filas: $np <br />";
	$associated = "INSERT INTO ".$association." SELECT sku, associated_skus, NULL error FROM ".$grouped_list;
	if ($db->exec($associated)) {
		echo "<br>Association Successfull <br>";
	}
	echo "Final ". date('Y-m-d g:i:a') ."<br />";


}
}
	
?>
<html>
<head><title>Crear listado para importar productos</title></head>
<body>
<form method="post" >
<input type="hidden" name="procesar_family" value="1"/>
<input type="submit" value="Crear listado para importar familia de productos" />
</form>
</body>
