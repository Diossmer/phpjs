﻿<?php
error_reporting(0);
set_time_limit(0);
include 'classImg.php';
//include 'obtener_listado_archivos.php';
$np=0;
//$conect="";
global $special_chars,$special_reemplazo,$simples_list,$grouped_list,$preliminar_list;
include 'vars.php';
include 'link.php';

$special_chars = array('+','&eacute;','&nbsp;','&frac14;','&deg;','&reg;','&trade;','!','@','$','%','*','"','”','\'','/','.'," ",',',':','.','½','³','¼','¾','(r)','(tm)','&copy;','&frac12;','&frac34;','&#133;','&#145;','&#146;','&#147;','&#148;','&#149;','&#150;','&#151;','&#153;',';','&','#','(',')');
$special_reemplazo = array('plus','e','','1-4','','','','','','','','','-','-','-','-','-',"-",'','','','1-2','3','1-4','3-4','','','','1-2','3-4','','','','','','','','','','','','','-','-');

function imagenes_seleccion($img,$imagenes_folder,$sku,$mf)
{
	global $special_chars,$special_reemplazo;

	$carpetas = array();
	//$carpeta_contenedora="D:\dux\Datos\StomaBags Dat\magento\gotcha";

	$carpeta_contenedora=$imagenes_folder;
	$carpeta_destino="imagenes_a_subir";
	$n=0;
	$no_encontradas = array();
	$img_encontrados=array();

	if(empty($carpeta_contenedora))
		return $img_encontrados;

	//echo print_r($img)." <br > $imagenes_folder <br > $sku <br> $mf";exit;

	$ni=0;
	foreach( $img as $image )
	{
	  if( empty( $image ) )
      {
          continue;
      }
	  $ni++;
      $archivo = trim( $image );

		$file_info = pathinfo($archivo);

		//temporal
		$archivo=$file_info['basename'];

		$nuevo_nombre = $mf.'-'.$sku;
		$nuevo_nombre=strtolower($nuevo_nombre);
		if($ni>1)
			$nuevo_nombre.='_'.$ni;
		$nuevo_nombre=str_replace($special_chars , $special_reemplazo , $nuevo_nombre).'.'.$file_info['extension'];
		echo("</br>Nuevo Nombre:".$nuevo_nombre);

      $encontrada=false;
      //foreach( $carpetas as $cr )
      //{
			if( file_exists( $carpeta_contenedora."\\".$archivo ) )
			{
				echo("</br>Image exists");
				$file_info = pathinfo( $archivo );
				//copy( $carpeta_contenedora."\\".$archivo , $carpeta_destino."\\".$nuevo_nombre );
				$image=new thumb();
				$image->loadImage($carpeta_contenedora."\\".$archivo);
				//redimensionando si es necesario
				if( $image->width > $image->height )
				{
					if( $image->width > 500 )
					{
						$image->resize(500, 'width');
					}
				}
				elseif( $image->height > 500 )
				{
					$image->resize(500, 'height');
				}

				$image->save($carpeta_destino.'\\'.$nuevo_nombre);

				$img_encontrados[]=$nuevo_nombre;
				$n++;
				$encontrada = true;
				//break;
			}
      //}
	}
	return $img_encontrados;
}

function EscapeSQL($val,$convertir=false)
{
    #Propocito:
    #genera un escape para caracteres especiales

    $resultante="";
    //Convirtiendo caracteres especiales a html
    if($convertir)
		$val=htmlentities($val);

    $resultante=AddSlashes($val);

	return $resultante;
}
if(isset($_POST['procesar']))
{

	$campos_molde=array("product_flavor"=>"","product_fragance"=>"","name_fam"=>"","id_fm"=>"","sku"=>"",
	"sku_supplier"=>"","sku_mf"=>"","store_view_code"=>"","attribute_set_code"=>"","product_type"=>"",
	"category_ids"=>"","product_websites"=>"","name"=>"","description"=>"","short_description"=>"","price"=>"",
	"weight"=>"","weight_product"=>"","manufacturer"=>"","supplier"=>"","type_update"=>"","fields_to_update"=>"","base_image"=>"","small_image"=>"",
	"thumbnail_image"=>"","additional_images"=>"","status"=>"","visibility"=>"","page_layout"=>"","options_container"=>"",
	"required_options"=>"","has_options"=>"","image_label"=>"","small_image_label"=>"","thumbnail_label"=>"",
	"tax_class_name"=>"","type_pouch"=>"","color_pouch"=>"","cost"=>"","sold_by"=>"","hcpcs"=>"","qty"=>"",
	"min_qty"=>"","use_config_min_qty"=>"","is_qty_decimal"=>"","backorders"=>"","use_config_backorders"=>"",
	"min_sale_qty"=>"","use_config_min_sale_qty"=>"","max_sale_qty"=>"","use_config_max_sale_qty"=>"","is_in_stock"=>"",
	"notify_stock_qty"=>"","use_config_notify_stock_qty"=>"","manage_stock"=>"","use_config_manage_stock"=>"",
	"stock_status_changed_auto"=>"","use_config_qty_increments"=>"","qty_increments"=>"","use_config_enable_qty_inc"=>"",
	"enable_qty_increments"=>"","is_decimal_divided"=>"","links_related_sku"=>"","links_related_position"=>"",
	"links_crosssell_sku"=>"","links_crosssell_position"=>"","links_upsell_sku"=>"","links_upsell_position"=>"",
	"tier_price_website"=>"","tier_price_customer_group"=>"","tier_price_qty"=>"","tier_price_price"=>"","url_key"=>"",
	"meta_title"=>"","meta_description"=>"","product_name_in_group"=>"","shipping_per_product"=>"","product_color"=>"",
	"product_video_embed"=>"","product_size"=>"","free_shipping"=>"","free_shipping_w_tax"=>"","product_options_custom"=>"",
	"supplier_abr"=>"",'supplier_original'=>'',"sold_by_qty"=>"","sold_by_uom"=>"","require_prescription"=>"",
	"youtube_video"=>"","comments"=>"","map_value"=>"","msrp_enabled"=>"","upc"=>"","product_online"=>"",
	"display_product_options_in"=>"","product_dimensions"=>"","sb_cols"=>"","description_in_group"=>"","brand"=>"",
	"meta_keyword"=>"","grouped"=>"","dropship"=>"", "shipping_cost"=>"",
	# bloque nuevo listas completas usa
	"additional_attributes"=>"","color_bag_wafer"=>"","is_fsa"=>"","max_cart_qty"=>"","min_cart_qty"=>"",
	"msrp_display_actual_price_type"=>"","out_of_stock_qty"=>"","product_notes"=>"","product_options_container"=>"",
	"special_price_from_date"=>"","special_price_to_date"=>""
	);
	#echo '<br/>Campos Molde count: '.count($campos_molde);

	$np=0;
	$n_parent=$n_child=0;
	//$special_chars = array('!','@','#','$','%','*','(',')','"','”','\'','/','.'," ",',',';','&');


	$i=0;
	$lista_campos='';
	foreach($campos_molde as $campo_nombre=> $val_campo)
	{
		if($i>0)
			$lista_campos .=",";

		$lista_campos .="`$campo_nombre`";
		$i++;
	}
	//cambiar consulta
	$consulta="
		/**/
		SELECT
		TRIM(REPLACE(CONCAT(a.`id`,'-',a.supplier_abr),' ','')) AS sku,
		TRIM(REPLACE(a.`id`,' ','')) AS sku_supplier,
		TRIM(REPLACE(a.`sku_mf`,' ','')) AS sku_mf,
		TRIM(a.id) AS id,
		upc,
		initcap(REPLACE(TRIM(`name`),'\'',''))AS `name`,
		initcap(REPLACE(TRIM(name_fam),'\'','')) AS name_fam,
		TRIM(id_fm) AS id_fm,
		TRIM(supplier_abr) AS supplier_abr,
		TRIM(supplier) AS supplier,
		TRIM(type_update) AS type_update,
		TRIM(fields_to_update) AS fields_to_update,
		TRIM(manufacturer) AS manufacturer,
		TRIM(size) AS size,
		TRIM(peso) AS peso,
		TRIM(color) AS color,
		TRIM(sabor) AS sabor,
		TRIM(fragancia) AS fragancia,
		TRIM(product_dimensions) AS product_dimensions,
		TRIM(free_shipping) AS free_shipping,
		TRIM(ROUND(TRIM(REPLACE(shipping_cost,',','.')),2)) AS shipping_cost,
		TRIM(ROUND(TRIM(REPLACE(dropship,',','.')),2)) AS dropship,
		TRIM(ROUND(TRIM(REPLACE(shipping_cost,',','.')),2)) + TRIM(ROUND(TRIM(REPLACE(dropship,',','.')),2)) + 
			IF(ROUND(TRIM(REPLACE(shipping_cost,',','.')),2) BETWEEN 1 AND 12,1,
			IF(ROUND(TRIM(REPLACE(shipping_cost,',','.')),2) BETWEEN 13 AND 20,1.50,
			IF(ROUND(TRIM(REPLACE(shipping_cost,',','.')),2) BETWEEN 21 AND 35,2,		
			IF(ROUND(TRIM(REPLACE(shipping_cost,',','.')),2) BETWEEN 36 AND 55,3,	
			IF(ROUND(TRIM(REPLACE(shipping_cost,',','.')),2) BETWEEN 56 AND 70,4,	
			IF(ROUND(TRIM(REPLACE(shipping_cost,',','.')),2) BETWEEN 71 AND 100,5,
			IF(ROUND(TRIM(REPLACE(shipping_cost,',','.')),2) BETWEEN 101 AND 200,7,
			IF(ROUND(TRIM(REPLACE(shipping_cost,',','.')),2) > 200,8,0)))))))) AS shipping,
		initcap(REPLACE(TRIM(REPLACE(product_description,'  ',' ')),'\'','')) AS `description`,
		initcap(REPLACE(TRIM(a.name_fam),'\'','')) AS product_name_in_group,
		initcap(REPLACE(TRIM(description_in_group),'\'','')) AS description_in_group,
		IF((SELECT COUNT(id_fm) FROM lista b WHERE b.id_fm = a.id_fm GROUP BY id_fm)>1,'Only Product View','Catalog, Search') AS visibility,
		TRIM(sold_by_uom) AS sold_by_uom,
		TRIM(sold_by_qty) AS sold_by_qty,
		TRIM(sold_by) AS sold_by,
		ROUND(TRIM(REPLACE(costo,',','.')),2) AS costo,
		ROUND(TRIM(REPLACE(REPLACE(price,'$',''),',','.')),2) AS price,
		ROUND(TRIM(REPLACE(map,',','.')),2) AS map_value,
		TRIM(brand) AS brand,
		TRIM(fragancia) AS fragancia,
		'simple' AS `type`,
		-- 1 atributo --							
		(IF(visibility='Catalog, Search','',
		 IF(description_in_group<>'' AND size='' AND color='' AND sabor='' AND fragancia='','sku_mf|Code,description_in_group|Description,sold_by|Sold by',
		 IF(description_in_group='' AND size<>'' AND color='' AND sabor='' AND fragancia='','sku_mf|Code,product_size|Size,sold_by|Sold by',
		 IF(description_in_group='' AND size='' AND color<>'' AND sabor='' AND fragancia='','sku_mf|Code,product_color|Color,sold_by|Sold by',
		 IF(description_in_group='' AND size='' AND color='' AND sabor<>'' AND fragancia='','sku_mf|Code,product_flavor|Flavor,sold_by|Sold by',
		 IF(description_in_group='' AND size='' AND color='' AND sabor='' AND fragancia<>'','sku_mf|Code,product_fragance|Fragance,sold_by|Sold by',
	   -- 2 atributos --       
		 IF(description_in_group<>'' AND size<>'' AND color='' AND sabor='' AND fragancia='','sku_mf|Code,description_in_group|Description,product_size|Size,sold_by|Sold by',
		 IF(description_in_group<>'' AND size='' AND color<>'' AND sabor='' AND fragancia='','sku_mf|Code,description_in_group|Description,product_color|Color,sold_by|Sold by',
		 IF(description_in_group<>'' AND size='' AND color='' AND sabor<>'' AND fragancia='','sku_mf|Code,description_in_group|Description,product_flavor|Flavor,sold_by|Sold by',
		 IF(description_in_group<>'' AND size='' AND color='' AND sabor='' AND fragancia<>'','sku_mf|Code,description_in_group|Description,product_fragance|Fragance,sold_by|Sold by',
		 IF(description_in_group='' AND size<>'' AND color<>'' AND sabor='' AND fragancia='','sku_mf|Code,product_size|Size,product_color|Color,sold_by|Sold by',
		 IF(description_in_group='' AND size<>'' AND color='' AND sabor<>'' AND fragancia='','sku_mf|Code,product_size|Size,product_flavor|Flavor,sold_by|Sold by',
		 IF(description_in_group='' AND size<>'' AND color='' AND sabor='' AND fragancia<>'','sku_mf|Code,product_size|Size,product_fragance|Fragance,sold_by|Sold by',
		 IF(description_in_group='' AND size='' AND color<>'' AND sabor<>'' AND fragancia='','sku_mf|Code,product_color|Color,product_flavor|Flavor,sold_by|Sold by',
		 IF(description_in_group='' AND size='' AND color<>'' AND sabor='' AND fragancia<>'','sku_mf|Code,product_color|Color,product_fragance|Fragance,sold_by|Sold by',
		 IF(description_in_group='' AND size='' AND color='' AND sabor<>'' AND fragancia<>'','sku_mf|Code,product_flavor|Flavor,product_fragance|Fragance,sold_by|Sold by',
	   -- 3 atributos --	   
		 IF(description_in_group<>'' AND size<>'' AND color<>'' AND sabor='' AND fragancia='','sku_mf|Code,description_in_group|Description,product_size|Size,product_color|Color,sold_by|Sold by',
		 IF(description_in_group<>'' AND size<>'' AND color='' AND sabor<>'' AND fragancia='','sku_mf|Code,description_in_group|Description,product_size|Size,product_flavor|Flavor,sold_by|Sold by',
		 IF(description_in_group<>'' AND size<>'' AND color='' AND sabor='' AND fragancia<>'','sku_mf|Code,description_in_group|Description,product_size|Size,product_fragance|Fragance,sold_by|Sold by',
		 IF(description_in_group<>'' AND size='' AND color<>'' AND sabor<>'' AND fragancia='','sku_mf|Code,description_in_group|Description,product_color|Color,product_flavor|Flavor,sold_by|Sold by',
		 IF(description_in_group<>'' AND size='' AND color<>'' AND sabor='' AND fragancia<>'','sku_mf|Code,description_in_group|Description,product_color|Color,product_fragance|Fragance,sold_by|Sold by',
		 IF(description_in_group='' AND size<>'' AND color<>'' AND sabor<>'' AND fragancia='','sku_mf|Code,product_size|Size,product_color|Color,product_flavor|Flavor,sold_by|Sold by',
		 IF(description_in_group='' AND size<>'' AND color<>'' AND sabor='' AND fragancia<>'','sku_mf|Code,product_size|Size,product_color|Color,product_fragance|Fragance,sold_by|Sold by',
		 IF(description_in_group='' AND size='' AND color<>'' AND sabor<>'' AND fragancia<>'','sku_mf|Code,product_color|Color,product_flavor|Flavor,product_fragance|Fragance,sold_by|Sold by',
	   -- 4 atributos --	      
		 IF(description_in_group<>'' AND size<>'' AND color<>'' AND sabor<>'' AND fragancia='','sku_mf|Code,description_in_group|Description,product_size|Size,product_color|Color,product_flavor|Flavor,sold_by|Sold by',
		 IF(description_in_group<>'' AND size='' AND color<>'' AND sabor<>'' AND fragancia<>'','sku_mf|Code,description_in_group|Description,product_color|Color,product_flavor|Flavor,product_fragance|Fragance,sold_by|Sold by',
		 IF(description_in_group<>'' AND size<>'' AND color='' AND sabor<>'' AND fragancia<>'','sku_mf|Code,description_in_group|Description,product_size|Size,product_flavor|Flavor,product_fragance|Fragance,sold_by|Sold by',
		 IF(description_in_group<>'' AND size<>'' AND color<>'' AND sabor='' AND fragancia<>'','sku_mf|Code,description_in_group|Description,product_size|Size,product_color|Color,product_fragance|Fragance,sold_by|Sold by',
		 IF(description_in_group<>'' AND size<>'' AND color<>'' AND sabor<>'' AND fragancia='','sku_mf|Code,description_in_group|Description,product_size|Size,product_color|Color,product_flavor|Flavor,sold_by|Sold by',
		 IF(description_in_group='' AND size<>'' AND color<>'' AND sabor<>'' AND fragancia<>'','sku_mf|Code,product_size|Size,product_color|Color,product_flavor|Flavor,product_fragance|Fragance,sold_by|Sold by',
	   -- 5 atributos --	       
		 IF(description_in_group<>'' AND size<>'' AND color<>'' AND sabor<>'' AND fragancia<>'','sku_mf|Code,description_in_group|Description,product_size|Size,product_color|Color,product_flavor|Flavor,product_fragance|Fragance,sold_by|Sold by',
		 'sku_mf|Code,sold_by|Sold By')))))))))))))))))))))))))))))))) AS sb_cols,
	   GROUP_CONCAT(b.nombre) AS img
	   FROM lista a
	   LEFT JOIN images b ON a.imagen = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(nombre,'.jpg',''),'.jpeg',''),'.png',''),'(A)',''),'(B)',''),'(C)',''),'(D)',''),'(E)',''),'(F)',''),'(G)',''),'(H)',''),'--2',''),'--3',''),'--4',''),'--5','')
	   GROUP BY id;
";

	$conect=mysqli_connect ("localhost", "root", "$password",$database )or die('I cannot connect to the database because: ');
	$rs = mysqli_query($conect, $consulta ) or die ( mysqli_error($conect) . " #001" );

		while( $row = mysqli_fetch_array($rs) )
		{
			$category_ids='';									//cambiar

			$abr = $row['supplier_abr'];									//cambiar
			$supplier =	$row['supplier'];							//cambiar
			$manufacturer_name = $row['manufacturer'];				//cambiar

			$sku_mf = trim($row['sku_mf']);						//cambiar
			$sku = trim($row['sku']);							//cambiar
			$sku_supplier = trim($row['sku_supplier']);			//cambiar

			$name = trim($row['name']);							//cambiar
			$name = str_replace("\n","",$name);
			$name = str_replace("\r","",$name);

			$id_fm ='';
			$id_fm = $row['id_fm'];
			$name_fam ='';
			$name_fam = $row['name_fam'];

			$brand='';
			$brand=$row['brand'];

			$description_in_group='';
			$description_in_group=$row['description_in_group'];

			$sb_cols='';
			$sb_cols=$row['sb_cols'];

			$meta_keyword='';
			//$meta_keyword=$row['meta_keyword'];

			$product_dimensions='';
			$product_dimensions=$row['product_dimensions'];

			$type='simple';								//cambiar
			//$type= $row['type'];						//cambiar

			$size='';										//cambiar
			$size=$row['size'];							//cambiar

			$color='';										//cambiar
			$color=$row['color'];						//cambiar

			$fragancia='';										//cambiar
			$fragancia=$row['fragancia'];						//cambiar

			$sabor='';										//cambiar
			$sabor=$row['sabor'];						//cambiar

			$weight = '';
			$weight = $row['peso']; 								//cambiar
				if ($weight=='') $weight=1.5;

			$weight_product = $weight ;

			$product_options_custom='';

			$short_description='';
			//$short_description=$row['short_description'];							//cambiar

			if (strlen($short_description)>"255")
				$short_description=$name;
			$short_description=str_replace("\n", "<br/>", $short_description);
			$short_description=str_replace("\r","",$short_description);

			//$description='';

			//cambiar
			$product_name_in_group=$row['product_name_in_group'];
			$description=$row['description'];
			$description=str_replace("\n", "<br/>", $description);
			$description=str_replace("\r","",$description);

			if(empty($description))
			{
				$description=$name;
				if(!empty($short_description))
					$description.='<br>-<br>'.$short_description;
			}

			if(empty($short_description))
			{
				$short_description=$name;
			}
			$hcpcs="";
			// $hcpcs=$row['hcpcs'];

			$upc='';
			$upc=$row['upc'];

			//$image='';
			$image=$row['img'];

			//$imagenes_folder="";															//cambiar
			$imagenes_folder="images";

			$imagearray=explode(',',$image);
			$imagenes=array();
			if(is_array($imagearray))
			{
				foreach($imagearray as $im)
				{
					$basename=basename($im);
					if(empty($basename))
						continue;
					$imagenes[]=$basename;
				}
			}

			$costo = $row['costo'];							//cambiar
			$precio = $row['price'];						//cambiar

			$map_value='';
			$map_value=$row['map_value'];
			
			$dropship='';
			$dropship=$row['dropship'];

			$msrp_enabled=0;						//1=Yes, 0=No

			$price_shipping='';								//cambiar
			$price_shipping=$row['shipping'];				//cambiar
			
			$shipping_cost='';								//cambiar
			$shipping_cost=$row['shipping_cost'];				//cambiar

			$free_shipping_w_tax="none";
			// $free_shipping="Yes";							//cambiar

			// $free_shipping="No";							//cambiar
			$free_shipping = $row['free_shipping'];
			$visibility='';
			$visibility=$row['visibility'];


			//$grouped='';
			if ($visibility=='Catalog, Search'){
				$grouped='No';}
				 else{
				 	$grouped='Yes';
				}

			$require_prescription='No';

			if(empty($require_prescription))							//cambiar
				$require_prescription='No';					//cambiar

			$status='1';									//default
			// $status=$row['status'];

			$comments='';								//cambiar
			// $comments=$row['comments'];				//cambiar

			$sold_by=''; 							//cambiar
			$sold_by_qty=''; 						//cambiar
			$sold_by_uom=''; 						//cambiar

			$sold_by=$row['sold_by'];						//cambiar
			$sold_by_qty=$row['sold_by_qty'];				//cambiar
			$sold_by_uom=$row['sold_by_uom'];				//cambiar

			$name_original=$name;

			$campos=array( 0 => $campos_molde );

			$special_htmlchars = array('”','™','•','®','‘','©','½','³','¼','¾',"(r)","(tm)",'&reg;');
			$special_htmlreemplazo = array('"','','-','','-','','&frac12;','&sup3;','&frac14;','&frac34;','','','');

			$name =  str_replace( $special_htmlchars , $special_htmlreemplazo , $name );
			$name2=$name;
			$name=$manufacturer_name;
			$name .= " - ".$row['sku_mf']." - ".$name2; // cambia del sku_mf a id
			
			$type_update='';
			$type_update=$row['type_update'];                    //para updates con productos nuevos

			$fields_to_update='';
			$fields_to_update=$row['fields_to_update'];              //para updates con productos nuevos

			$description = str_replace( $special_htmlchars , $special_htmlreemplazo , $description );

			$short_description = str_replace( $special_htmlchars , $special_htmlreemplazo , $short_description );

			$campos[0]['sku']=EscapeSQL( $sku);
			$campos[0]['sku_supplier']=EscapeSQL( $sku_supplier);
			$campos[0]['sku_mf']=EscapeSQL($sku_mf);

			if(empty($campos[0]['sku_mf']))
				$campos[0]['sku_mf']=$campos[0]['sku'];

			$campos[0]['id_fm']=$id_fm;									//añadir campo a tabla
			$campos[0]['name_fam']=$name_fam;
			$campos[0]['meta_keyword']=$meta_keyword;
			$campos[0]['brand']=$brand;
			$campos[0]['description_in_group']=$description_in_group;
			$campos[0]['product_dimensions']=$product_dimensions;
			$campos[0]['sb_cols']=$sb_cols;							//añadir campo a tabla
			$campos[0]['attribute_set_code']='Migration_Default';
			$campos[0]['store_view_code']='';
			$campos[0]['product_online']='1';
			$campos[0]['product_websites']='base';
			$campos[0]['display_product_options_in']='Block after Info Column';
			$campos[0]['weight']=$weight;
			$campos[0]['weight_product']=$weight_product;
			$campos[0]['name']=EscapeSQL($name);
			$campos[0]['product_name_in_group']=EscapeSQL($product_name_in_group);
			$campos[0]['description']= EscapeSQL($description);
			$campos[0]['short_description']= EscapeSQL($short_description);
			$campos[0]['manufacturer']=EscapeSQL($manufacturer_name);
			$campos[0]['supplier']=$supplier;
			$campos[0]['supplier_original']=$supplier;
			$campos[0]['supplier_abr']=$abr;
			$campos[0]['type_update']=$type_update;
			$campos[0]['fields_to_update']=$fields_to_update;
			$campos[0]['product_type']=$type;
			$campos[0]['status']=$status;
			$campos[0]['visibility']=$visibility;
			$campos[0]['page_layout']='1 column';
			$campos[0]['options_container']='Product Info Column';
			$campos[0]['required_options']=0;
			$campos[0]['has_options']=0;
			$campos[0]['tax_class_name']='ALL';
			$campos[0]['cost']=$costo;
			$campos[0]['sold_by']=EscapeSQL($sold_by);
			$campos[0]['sold_by_qty']=EscapeSQL($sold_by_qty);
			$campos[0]['sold_by_uom']=EscapeSQL($sold_by_uom);
			$campos[0]['hcpcs']=$hcpcs;
			$campos[0]['upc']=$upc;
			$campos[0]['qty']=100;
			$campos[0]['min_qty']=0;
			$campos[0]['use_config_min_qty']=1;
			$campos[0]['is_qty_decimal']=0;
			$campos[0]['backorders']=0;
			$campos[0]['use_config_backorders']=1;
			$campos[0]['min_sale_qty']=1;//cantidades minimas en el carrito
			$campos[0]['use_config_min_sale_qty']=1;//cantidades minimas en el carrito
			$campos[0]['max_sale_qty']=0;
			$campos[0]['use_config_max_sale_qty']=1;
			$campos[0]['is_in_stock']=1;
			$campos[0]['use_config_notify_stock_qty']=1;
			$campos[0]['notify_stock_qty']=1;
			$campos[0]['manage_stock']=0;
			$campos[0]['use_config_manage_stock']=1;
			$campos[0]['stock_status_changed_auto']=0;
			$campos[0]['use_config_qty_increments']=1;
			$campos[0]['qty_increments']=0;
			$campos[0]['use_config_enable_qty_inc']=1;
			$campos[0]['enable_qty_increments']=0;
			$campos[0]['is_decimal_divided']=0;
			$campos[0]['shipping_per_product']=$price_shipping;
			$campos[0]['product_size']=EscapeSQL($size);
			$campos[0]['product_color']=EscapeSQL($color);
			$campos[0]['product_fragance']=EscapeSQL($fragancia);
			$campos[0]['product_flavor']=EscapeSQL($sabor);
			$campos[0]['require_prescription']=$require_prescription;
			$campos[0]['comments']=$comments;
			$campos[0]['map_value']=$map_value;
			$campos[0]['msrp_enabled']=$msrp_enabled;
			$campos[0]['grouped']=$grouped;
			$campos[0]['free_shipping']=$free_shipping;				///cambiar
			$campos[0]['dropship']=$dropship;
			$campos[0]['shipping_cost']=$shipping_cost;

			# campos para listas completas usa
			$campos[0]['product_options_container']='Product Info Column';
			$campos[0]['additional_attributes']='has_options=0,quantity_and_stock_status=In Stock,required_options=0';
			$campos[0]['color_bag_wafer']='';
			$campos[0]['is_fsa']='No';
			$campos[0]['min_cart_qty']='1';
			$campos[0]['msrp_display_actual_price_type']='';
			$campos[0]['out_of_stock_qty']='0';
			$campos[0]['product_notes']='';
			$campos[0]['special_price_from_date']='';
			$campos[0]['special_price_to_date']='';

			if( count( $imagenes ) > 0 )
			{
				$imagenes2=imagenes_seleccion($imagenes,$imagenes_folder,$sku_mf,$manufacturer_name);
				if( count( $imagenes2 ) > 0 )
				{
					$campos[0]['base_image']=$imagenes2[0];
					$campos[0]['small_image']=$imagenes2[0];
					$campos[0]['thumbnail_image']=$imagenes2[0];
					$campos[0]['additional_images']=implode( ',' , $imagenes2 );
				}
			}

			$campos[0]['price']=$precio;


			$url_key = trim($manufacturer_name) . "-" . trim($row['sku']) . "-" . trim($name2);#."-".$sold_by_uom;
			$url_key=strtolower(trim($url_key,'-'));
			$url_key=str_replace(' ' , '-' , $url_key);
			$url_key=str_replace('+' , 'plus' , $url_key);
			$url_key=trim(str_replace('*','-',str_replace(',','-',str_replace(' ','-',str_replace('&','-',str_replace('/','-',str_replace(')','-',str_replace('(','-',str_replace('"','-',str_replace('+','plus',str_replace('.' , '' , str_replace(' ' , '-' , strtolower(trim($url_key,'-'))))))))))))));
			$url_key=str_replace('#' , '-' , $url_key);
			$url_key=str_replace(':' , '-' , $url_key);
			$url_key=str_replace(';' , '-' , $url_key);
			$url_key=str_replace('_' , '-' , $url_key);
			$url_key=str_replace('%' , '-' , $url_key);


			if(substr($url_key, -1)=='-')
				$url_key=substr($url_key, 0, -1);

			while(strpos($url_key,'--')){
				$url_key=str_replace('--' , '-' , $url_key);
			}

			if (strlen($url_key)>255)
				$url_key=substr($url_key,0,254);

			$campos[0]['url_key']=$url_key;

			//metadescripciones
			$meta_description="";	
			$meta_description .="$manufacturer_name: $sku_mf, $description, $color, $size, $sold_by";
			while(strpos($meta_description,', , '))
				$meta_description=str_replace(', , ' , ', ' , $meta_description);
			$meta_description=trim(trim($meta_description),',');
			$meta_description=strip_tags($meta_description);
			$meta_description=str_replace("\n",'',$meta_description);
			$meta_description=str_replace("\"",'',$meta_description);
			$meta_title=$name;
			
			//truncar limite 
			if (strlen($meta_description)>255){
				$meta_description=substr($meta_description,0,254);
				$meta_description=substr($meta_description,0,strrpos($meta_description, " "));
			}
						
			$campos[0]['meta_title']=EscapeSQL($meta_title);
			$campos[0]['meta_description']=EscapeSQL($meta_description);

			$campos[0]['category_ids']=$category_ids;

			// echo '<br/>Campos count: '.count($campos[0]);

			foreach($campos as $fila=>$c )
			{
				$query ="INSERT INTO ".$simples_list." ( $lista_campos )values(";
				$i=0;
				foreach($c as $valor)
				{
					if($i>0)
						$query .=",";
					$query .='\''.$valor.'\'';
					$i++;
				}
				$query .= ")";
				mysqli_query($conect, $query)or die(mysqli_error($conect)." #006 <br /> ".$query);
				$np++;
			}
		}
		$list_group="
				/*para crear tabla de grupos*/
				create table ".$preliminar_list." SELECT GROUP_CONCAT( DISTINCT id_fm) id_grp,
				manufacturer,
				manufacturer `manufacturer2`,
				''  sku_fam,
				GROUP_CONCAT(sku) sku1,
				GROUP_CONCAT(sku SEPARATOR '|')  sku2,
				GROUP_CONCAT(DISTINCT sku_mf )  sku_mfs_list,
				GROUP_CONCAT(sku_mf SEPARATOR '|') AS sku_mf,
				GROUP_CONCAT(CONCAT(sku,'::',sku_mf) SEPARATOR '|')  sku_ord,
				GROUP_CONCAT(CONCAT(sku,'::',price) SEPARATOR '|') sku_ord2,
				COUNT(*)  `count`,
				COUNT(DISTINCT sku_mf)  count_sku_mf,
				COUNT(DISTINCT sold_by) count_sold_by,
				COUNT(DISTINCT product_size) count_product_size,
				GROUP_CONCAT(DISTINCT `name_fam` SEPARATOR '|||') new_name,
				GROUP_CONCAT(DISTINCT `sb_cols` SEPARATOR '|||') sb_group_additional_cols, /*****CAMBIAR SEGUN SE TENGA EL SIZE Y EL SOLD BY******/
				'Custom Columns'  sb_group_style,
				IF(additional_images LIKE '%,%', SUBSTRING(`additional_images`,1,LOCATE(',',`additional_images`)-1),additional_images) image
				,additional_images gallery
				FROM " .$simples_list. "
				GROUP BY id_fm
				HAVING COUNT(*)>1";

			if(mysqli_query($conect, $list_group)or die(mysqli_error($conect)." #007 <br /> ".$list_group))
			{
				echo "<br>Query Ok <br>";
			}
}

if($np >0 )
{
 echo "Numero de filas: $np <br />";
}
?>
<html>
<head><title>Crear listado para importar productos</title></head>
<body>
<form method="post" >
<input type="hidden" name="procesar" value="1"/>
<input type="submit" value="Crear listado para importar productos simples" />
</form>
</body>
</html>
<?php

	include 'import_family.php';

 ?>
