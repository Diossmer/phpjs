<?php
if (isset($_POST['continuar'])) {
	header('Location: Import_simples.php');
}else{	
set_time_limit(0);
include 'vars.php';
$dir="/var/www/html/listas/images";
$directorio=opendir($dir); 
echo "<b>Directorio actual:</b><br>$dir<br>"; 
$n=0;
$cn=mysqli_connect ("localhost", "root", "$password",$database )or die('I cannot connect to the database because:');
while( $archivo = readdir($directorio))
{
	$archivo=basename($archivo);
	echo $archivo.'<br>';
	mysqli_query($cn,"INSERT INTO `images`(`nombre`)VALUES('$archivo')")or die(mysql_error() . " #err mysql");
	$n++;
}
closedir($directorio); 
echo "Total:$n ";
}
?> 
<form method="post" >
<input type="hidden" name="continuar" value="1"/>
<input type="submit" value="continuar" />
</form>
